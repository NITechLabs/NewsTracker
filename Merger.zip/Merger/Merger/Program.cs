﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MergeFiles;

namespace Merger
{
    class Program
    {
        static void Main(string[] args)
        {
            //string path, string fileName, string extension, string[] weProjects
            string path = ".\\Logs\\";
            string fileName = "20141208";
            string extension = "_clean.txt";
            string[] weProjects = new string[10];
            weProjects[0] = "ad.nl";
            weProjects[1] = "bnr.nl";
            weProjects[2] = "limburger.nl";
            weProjects[3] = "lindanieuws.nl";
            weProjects[4] = "nu.nl";
            MergeResultFiles myMerger = new MergeResultFiles();
            myMerger.Merge(path, fileName, extension, weProjects);
        }
    }
}
