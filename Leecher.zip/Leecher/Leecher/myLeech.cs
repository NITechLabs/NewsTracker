﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Threading;

namespace Leecher
{
    public class myLeech
    {
        string[] currentDomain = new string[10000];
        string[] countryCode = new string[10000];
        string[,] url = new string[10000,2];
        string[,] processedUrl = new string[10000,2];

        public string[] GetContent(string pathRoot, string pathProxy, string pathLogsRaw, string pathLogsClean, string pathContent, string pathConfig, string pathTemplates, string pathLogsFinal, string fileName, string extension)
        {
            string[,] rawUrl = new string[10000,2];
            string[] projectName = new string[500];
            int index = 0;
            int indexNew = 0;
            string domainName;
            string cleanedLogFile = pathLogsClean + fileName + extension;

            //Check if Web Extractor is running
            foreach (Process clsProcess in Process.GetProcesses())
            {
                //Console.WriteLine(clsProcess.ProcessName);
                if (clsProcess.ProcessName.Contains("WCExtractor"))
                {
                    //If running wait until quit. This assumes that the WE is still processing a previous set of URLs
                    Console.WriteLine("Web Extractor is already running. Killing!");
                    //Console.ReadKey();
                    //Environment.Exit(1);
                    System.Diagnostics.Process[] procs = null;
                    try
                    {
                        procs = Process.GetProcessesByName("WCExtractor");
                        Process WEx = procs[0];
                        if (!WEx.HasExited)
                        {
                            WEx.Kill();
                        }
                    }
                    finally
                    {
                        if (procs != null)
                        {
                            foreach (Process p in procs)
                            {
                                p.Dispose();
                            }
                        }
                    }
                }
            }

            //Get retrieval list (which URLS to get the content from) from txt file
            //LoadRetrieval();

            //Read through the cleaned log file
            //StreamReader logFile = new StreamReader(".\\Logs\\logfile.txt");
            StreamReader logFile = new StreamReader(cleanedLogFile);

            while (true)
            {
                string line = logFile.ReadLine();
                if (line == null) { break; }
                //Fields are separated by commas (,)
                //(1) Date (2) Time (3) User (4) session id (5) time taken (ms) (6) user IP (7) URL (8) bytes
                
                int countComma = 0;
                int commaPos = 0;
                while (countComma < 3) //Scan to session id
                {
                    commaPos = line.IndexOf(",", commaPos + 1);
                    countComma++;
                }
                rawUrl[index,0] = line.Substring(commaPos + 1, (line.IndexOf(",", commaPos + 1) - 1) - commaPos); //Store session ID
                while (countComma < 6) //Scan to url
                {
                    commaPos = line.IndexOf(",", commaPos + 1);
                    countComma++;
                }
                rawUrl[index, 1] = line.Substring(commaPos + 1, (line.IndexOf(",", commaPos + 1) - 1) - commaPos); //Store url

                index++;
            }

            rawUrl = sortArray(rawUrl, index);

            //Array.Sort(rawUrl); //Make sure all the entries are sequential, not spread out over the array
            //Array.Reverse(rawUrl); //Flip it so the values are "on top"
            index = 0;
            string prevUrl = rawUrl[index,1];
            processedUrl[indexNew, 0] = rawUrl[index, 0];
            processedUrl[indexNew, 1] = rawUrl[index, 1];
            index++;
            indexNew++;
            while (rawUrl[index,1] != null) //Clean the array to remove double entries
            {
                if (rawUrl[index,1] != prevUrl) //If this one is NOT the same as the previous one, put it into the next array url[]
                {
                    processedUrl[indexNew, 0] = rawUrl[index, 0];
                    processedUrl[indexNew, 1] = rawUrl[index, 1];
                    indexNew++;
                }
                prevUrl = rawUrl[index,1];
                index++;
            }

            extractDomain(processedUrl);

            //Get the retrieval list
            //This holds the domain names, the WE project file name for each
            projectName = LoadRetrieval(pathTemplates);
            //Clean the urls to hold only those for which we have WE project files
            index = 0;
            int indexURL = 0;
            while (processedUrl[index,1] != null) //Scan through all the urls
            {
                bool continueLoop = true;
                int i = 0;
                while(continueLoop)
                {
                    if (projectName[i] != null)
                    {
                        if (currentDomain[index] == projectName[i]) //If the current domain name of the current url has a WE project file
                        {
                            url[indexURL, 0] = processedUrl[index, 0]; //Transfer this session id
                            url[indexURL, 1] = processedUrl[index, 1]; //Transfer this url to the final array
                            indexURL++;
                        }
                    }
                    else
                    {
                        continueLoop = false;
                    }
                    i++;
                }
                index++;
            }

            extractDomain(url); //Find the domain name and extension of each of the final urls
            
            //Build Web Extractor query
            //Now build the temporary file that holds 1-by-1 the urls of 1 domain that will be processed by WE
            //Need to do this one-by-one because there may be URLs that return no content and WE will then skip that entry,
            //that makes it impossible to like the original logfile entry to the extracted content.
            int maxIndex = indexURL;
            index = 0;
            domainName = currentDomain[index];
            //Open the output file to empty it
            while (index < maxIndex)
            {
                //if (currentDomain[index] != null)
                //{
                StreamWriter contentOutFile = new StreamWriter(pathContent + fileName + "_content_" + domainName.Replace(".", "_") + ".txt"); //The new content output file for this domain name

                while (currentDomain[index] == domainName) //As long as the same domain name is found
                {
                    StreamWriter urls = new StreamWriter(pathTemplates + "url.txt"); //This will hold a single url

                    urls.WriteLine(url[index, 1]); //write the url
                    urls.Close();

                    //Execute Web Extractor query
                    Console.WriteLine("Processing urls from " + currentDomain[index] + ": " + url[index,1]);
                    WEstart(pathTemplates, domainName, index);
                    
                    //Build the content output file
                    StreamReader contentInFile = new StreamReader(pathTemplates + "output.txt"); //The WE output file for this domain name
                    //string readLine = contentInFile.ReadLine(); //read the first line, holding the column names
                    string readLine = contentInFile.ReadLine(); //Get the data line, returns null if empty
                    if (readLine != null)
                    {
                        //int comma1 = readLine.IndexOf(",");//Find the first comma
                        //readLine = readLine.Substring(comma1 + 1);//Strip the line of the ID from WebExtractor
                        int quote1 = readLine.IndexOf("\'", 1); //First quote is on position 0 always, find the next to define the image file name
                        string imageName = readLine.Substring(1, quote1 - 1); //extract just the file name
                        if (imageName != "") //if there is an image, rename and move
                        {
                            readLine = readLine.Replace(imageName, url[index, 0] + "_" + imageName); //Substitute the image file name by adding the session ID as a prefix
                            string sourceFolder = pathTemplates + domainName.Replace(".", "_") + "_Images\\"; //Construct the folder name which hold the image
                            string destinationFolder = pathLogsFinal + domainName.Replace(".", "_") + "_Images\\"; //Construct the folder name which hold the image
                            string serverFolder = @"\\145.108.224.10\NewsTracker\" + domainName.Replace(".", "_") + "_Images\\";
                            if (!Directory.Exists(destinationFolder))
                            {
                                try
                                {
                                Directory.CreateDirectory(destinationFolder);
                                }
                                catch (IOException ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                            }
                            if (!Directory.Exists(serverFolder))
                            {
                                try
                                {
                                    Directory.CreateDirectory(serverFolder);
                                }
                                catch (IOException ex)
                                {
                                    Console.WriteLine(ex.Message);
                                }
                            }

                            try //Copy to local results folder
                            {
                                File.Copy(sourceFolder + imageName, destinationFolder + url[index, 0] + "_" + imageName); //Rename the image file by adding the session ID
                            }
                            catch (IOException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            try //copy to server folder
                            {
                                File.Copy(sourceFolder + imageName, serverFolder + url[index, 0] + "_" + imageName); //Rename the image file by adding the session ID
                            }
                            catch (IOException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                        }
                        contentOutFile.WriteLine(url[index, 0] + "," + readLine);//Write Logfile sessions ID and the WebExtractor content extracted data
                    }
                    contentInFile.Close();
                    index++;
                }
                domainName = currentDomain[index];
                contentOutFile.Close();
                //}
            }
            return projectName; //Return to Clean.cs an take the WE projects array along to pass to the Merger class
        }

        void WEstart(string pathTemplates, string thisDomain, int suffix)
        {
            Console.WriteLine("Starting extration");
            //Check if Web Extractor is running
            foreach (Process clsProcess in Process.GetProcesses())
            {
                //Console.WriteLine(clsProcess.ProcessName);
                if (clsProcess.ProcessName.Contains("WCExtractor"))
                {
                    //If running wait until quit. This assumes that the WE is still processing a previous set of URLs
                    Console.WriteLine("Web Extractor is already running. Killing!");
                    //Console.ReadKey();
                    //Environment.Exit(1);
                    System.Diagnostics.Process[] procs = null;
                    try
                    {
                        procs = Process.GetProcessesByName("WCExtractor");
                        Process WEx = procs[0];
                        if (!WEx.HasExited)
                        {
                            WEx.Kill();
                        }
                    }
                    finally
                    {
                        if (procs != null)
                        {
                            foreach (Process p in procs)
                            {
                                p.Dispose();
                            }
                        }
                    }
                }
            }

            //Both the url.txt and the output.txt are located in the WEprojects folder, the fodler of the current WE project file
            thisDomain = thisDomain.Replace(".", "_"); //change the dot to underscore for the WE project file name

            ProcessStartInfo startinfo = new ProcessStartInfo();
            //Proxy setting
            //startinfo.FileName = @"c:\program files\Web Content Extractor\WCExtractor.exe";
            //Debug setting PC Marco
            startinfo.FileName = @"c:\program files (x86)\Web Content Extractor\WCExtractor.exe";
            //Arguments
            //Location and name of the Project file containing the extraction details of the source
            //-dr = delete previous results, -dt delete previous URLS
            //-at Specifies the txt file that contains the URLs that should be leeched, location relative to Project file!
            //-s do the leeching
            //-qe Export the results using latest export done in this project. SO create at least one manual export in the program before doing it over the command line!!!
            //-ex exit program when done
            //string arguments = "\"Config\\limburger_nl.wcepr\"" + " -dr -dt -at" + "\"urls_limburger.txt\"" + " -s -qe" + "\"output.txt\"" + " -ex";
            // "\".\\Config\\WEprojects\\" + thisDomain + ".wcepr\"" + " -dr -dt -at" + "\"url.txt\"" + " -s -qe" + "\"output.txt\"" + " -ex"; //_" + thisDomain + "
            //string addString = ".wcepr\"" + " -dr -dt -at" + "\"url.txt\"" + " -s -qe" + "\"output.txt\"" + " -ex";
            string arguments = "\"" + pathTemplates + thisDomain + ".wcepr\"" + " -dr -dt -at" + "\"url.txt\"" + " -s -qe" + "\"output.txt\"" + " -ex";
            startinfo.Arguments = arguments;
            Process.Start(startinfo);

            //Wait for Web Extractor to finish
            int counter = 0;
            bool keepWaiting = true;
            bool killing = false;
            while (keepWaiting)
            {
                keepWaiting = false; 
                foreach (Process clsProcess in Process.GetProcesses())
                {
                    //Console.WriteLine(clsProcess.ProcessName);
                    //if (clsProcess.ProcessName.Contains("WCEXTR")) //PC Marco
                    if (clsProcess.ProcessName.Contains("WCExtractor")) //Proxy
                    {
                        //If running wait until quit. This assumes that the WE is still processing a previous set of URLs
                        //Optional: add check for hanging, ie after more than 1 minute, kill the extractor, possibly run it again
                        counter++;
                        Console.Write(".");
                        keepWaiting = true;
                        Thread.Sleep(1000);
                        if (counter > 120 && !killing)
                        {
                            //We've waited 120s = 2 minutes - let's kill the app and waste this URL
                            Console.WriteLine("Web Extractor is still running (120s+). Killing!");
                            killing = true;
                            System.Diagnostics.Process[] procs = null;
                            try
                            {
                                procs = Process.GetProcessesByName("WCExtractor");
                                Process WEx = procs[0];
                                if (!WEx.HasExited)
                                {
                                    WEx.Kill();
                                }
                            }
                            finally
                            {
                                if (procs != null)
                                {
                                    foreach (Process p in procs)
                                    {
                                        p.Dispose();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Console.WriteLine();
        }

        string[] LoadRetrieval(string pathTemplates)
        //This loads the \Config\WEprojects folder and loads all available WE project files into the array names
        //These are all the domainnames for which there are content templates to extract content
            //POSSIBLE issue: if the domainname has underscores in the name, the "replace" command needs to be changed to just replace the last underscore to a period
        {
            string[] names = new string[500]; //Create temp array
            string[] folderContent = Directory.GetFiles(pathTemplates); //@".\Config\WEprojects" // .\\Config\\WEproject\\<name>.wcepr
            int index = 0;
            while (index < folderContent.Length)
            {
                int doubleBackSlash = folderContent[index].IndexOf("\\"); //Get first backslashes
                doubleBackSlash = folderContent[index].IndexOf("\\", doubleBackSlash + 1); //Get next backslashes
                doubleBackSlash = folderContent[index].IndexOf("\\", doubleBackSlash + 1); //Get last double backslash
                int pointPosition = folderContent[index].IndexOf(".", doubleBackSlash); //Get the extension period
                string domainName = folderContent[index].Substring(doubleBackSlash + 1, pointPosition - doubleBackSlash - 1); //Extract domain name
                domainName = domainName.Replace("_", "."); //replace the underscore with a period
                names[index] = domainName; //stuff into the array
                index++;
            }
            return names; //return the results
        }

        void extractDomain(string[,] theURLS)
        {
            //Go through the clean array and extract the parts
            Array.Clear(countryCode,0, countryCode.Length);
            Array.Clear(currentDomain, 0, currentDomain.Length);
            int index = 0;
            while (theURLS[index,1] != null)
            {
                //Extract the domain name and country code
                int doubleSlashPos = theURLS[index,1].IndexOf("//");
                int slashPos = theURLS[index,1].IndexOf("/", doubleSlashPos + 2);
                string fullDomainName = theURLS[index,1].Substring(doubleSlashPos + 2, slashPos - doubleSlashPos - 2); //Extract the full domain reference between the // and first single /
                int lastDot = fullDomainName.LastIndexOf(".");
                int prevDot = fullDomainName.LastIndexOf(".", lastDot - 1);
                string domainName = fullDomainName.Substring(prevDot + 1, lastDot - prevDot - 1);
                countryCode[index] = fullDomainName.Substring(lastDot + 1, fullDomainName.Length - lastDot - 1);
                currentDomain[index] = domainName + "." + countryCode[index];
                //Console.WriteLine(currentDomain[index]);
                index++;
            }
            return;
        }

        string[,] sortArray(string[,] theArray, int maxIndex)
        {
            for (int i = 0; i < maxIndex; i++)
            {
                int index = 0;
                bool doLoop = false;
                while (index < maxIndex && theArray[index + 1, 1] != null)
                {
                    if (string.Compare(theArray[index, 1], theArray[index + 1, 1]) == 1) //current url is alphabetically larger than the next
                    {
                        //swapping
                        string temp1 = theArray[index + 1, 0]; //sessions id
                        string temp2 = theArray[index + 1, 1]; //url
                        theArray[index + 1, 0] = theArray[index, 0];
                        theArray[index + 1, 1] = theArray[index, 1];
                        theArray[index, 0] = temp1;
                        theArray[index, 1] = temp2;
                        doLoop = true; //If there is a swap, then repeat the outer loop
                    }
                    index++;
                }
                if (!doLoop) { break; } //If there's no swap any more, then we're done
            }
            return theArray;
        }
    }
}
