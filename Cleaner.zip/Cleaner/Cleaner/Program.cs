﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cleaner
{
    class Program
    {
        static void Main(string[] args)
        {
            Clean myCleaner = new Clean();
            //Do the arguments check
            if (args.Length == 0) //no arguments, run yesterdays log file
            {
                myCleaner.cleanLogFile("");
            }
            else
            {
                if (args.Length > 1)
                {
                    Console.WriteLine("Only 1 argument accepted: YYYYMMDD");
                    Environment.Exit(0); //Quit the cleaner
                }
                string theDate = args[0]; //Get the string
                int n;
                bool dateIsNumber = int.TryParse(theDate, out n);
                if(!dateIsNumber)
                {
                    Console.WriteLine("Argument must be a number: YYYYMMDD");
                    Environment.Exit(0); //Quit the cleaner
                }
                if(theDate.Length != 8){
                    Console.WriteLine("Wrong format, the format should be 8 digits: YYYYMMDD");
                    Environment.Exit(0); //Quit the cleaner
                }
                int year;
                bool yearIsNumber = int.TryParse(theDate.Substring(0, 4), out year);
                int month;
                bool monthIsNumber = int.TryParse(theDate.Substring(4, 2), out month);
                int day;
                bool dayIsNumber = int.TryParse(theDate.Substring(6, 2), out day);
                if(year != 2015){
                    Console.WriteLine("Can only accept a date in the year: 2015");
                    Environment.Exit(0); //Quit the cleaner
                }
                if(month < 1 || month > 12)
                {
                    Console.WriteLine("Month must be between 01 and 12");
                    Environment.Exit(0); //Quit the cleaner
                }
                if(day < 1 || day > 31)
                {
                    Console.WriteLine("Day must be between 01 and 31");
                    Environment.Exit(0); //Quit the cleaner
                }
                //No check for 28 or 30 days per month!!
                //All checks are positive so run the cleaner with this date!
                myCleaner.cleanLogFile(theDate);
            }
        }
    }
}
