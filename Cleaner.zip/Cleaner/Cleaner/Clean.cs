﻿//This program reads the WinGate WWW Proxy files and strips the file down to only the URLs
//that are in the allowed list and reformats the columns
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Leecher;
using MergeFiles;

namespace Cleaner
{
    class Clean
    {
        //root folder
        //.\\Proxy Raw holds the WinGate Proxy log files
        // .\\News Tracker is the main processing folder and holds the executables etc
        // .\\News Tracker\\Logs Raw holds the copies of the proxy files
        // .\\News Tracker\\Logs Clean holds the cleaned files from the clean.cs code
        // .\\News Tracker\\Content holds the extracted web page content including the final images
        // .\\News Tracker\\Config holds the uri files and temporary Web Extractor files
        // .\\News Tracker\\Config\WEprojects holds the WE project templates
        string pathRoot = ".\\"; //base folder were the exes are
        //Running on Proxy
        //string pathProxy = "..\\Proxy Raw\\"; //the Wingate proxy log files
        //Running on Marco's PC
        string pathProxy = "P:\\";
        string pathLogsRaw = ".\\Logs Raw\\"; //the copied files to process
        string pathLogsClean = ".\\Logs Clean\\";
        string pathContent = ".\\Content\\";
        string pathConfig = ".\\Config\\";
        string pathTemplates = ".\\Config\\WEprojects\\";
        string pathLogsFinal = ".\\Logs Final\\";

        StreamReader rawLogFile;
        StreamWriter cleanedLogFile;
        string[,] allowedURI = new string[5000, 4]; //holds all the URIs we do want 500
        string[,] blockURI = new string[5000, 4]; //Holds all the URIs we do not want 500
        string[] allowedExtensions = new string[50];
        int numberAllowedURI = 0;
        int numberBlockedURI = 0;
        int index;
        string fileName = "";

        string thisDate = "";
        string thisTime = "";
        string thisUser = "";
        string thisSessionID = "";
        string prevDate = "";
        string prevTime = "";
        string prevUser = "";
        string prevSessionID = "";
        string prevURI = "";
        string thisURI = "";

        myLeech ContentExtractor = new myLeech(); ///Instantiate the leechter program
        MergeResultFiles FileMerger = new MergeResultFiles(); //Instantiate the merge files program

        public void cleanLogFile(string theDate)
        {
                //path = "c:\\Program Files\\WinGate\\Logs\\WWW Proxy Server Usage\\";
                index = 0; //Start with file '0' of today
                allowedURI = getURIs(1); //Get URIs to keep
                blockURI = getURIs(0); //Get URIs to loose from the keep list
                fillExtensions();

                if (theDate == "") //No dat on command line given
                {
                    fileName = getDate(index); //Get the dated file name of yesterday
                }
                else
                {
                    string suffixName = "WWW Proxy Server.log";
                    fileName = theDate + "_000" + "_" + suffixName;
                    Console.WriteLine(fileName);
                    Console.ReadKey();
                }

                //Copy the raw proxy log file to the local Logs folder
                try
                {
                    File.Copy(pathProxy + fileName, pathLogsRaw + fileName);
                }
                catch (IOException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                rawLogFile = new StreamReader(pathLogsRaw + fileName); //Open the log file of yesterday
                cleanedLogFile = new StreamWriter(pathLogsRaw + fileName.Substring(0, 8) + "_cleantemp.txt");

                bool blockIt = false;

                for (int i = 0; i < 5; i++)
                {
                    string temp = rawLogFile.ReadLine(); //skip first 5 lines
                }
                while (true)
                {
                    bool readDateTime = false;
                    string logEntry = rawLogFile.ReadLine();
                    if (logEntry == null) { break; } //EOF then quit while loop
                    /*
                    if(logEntry.IndexOf("facebook")!=-1){
                        if (logEntry.IndexOf("rtlnieuws") != -1)
                        {
                            Console.WriteLine("HALT");
                        }
                    }
                    */
                    //process \t is TAB delimiter
                    //FIELDS
                    //date -1 time -2 USER -3 id -4 time taken -5 client ip -6 agent -7 server ip -8 method -9 URI -10 query - status (int) - client bytes - server bytes - protocol - referer
                    //Selection on URI only!
                    int tab1 = 0;
                    int tab2 = 0;
                    for (int i = 0; i < 4; i++) //scan through the log entry record to extract the fields we need
                    {
                        tab1 = logEntry.IndexOf("\t", tab2 + 1);
                        tab2 = logEntry.IndexOf("\t", tab1 + 1);
                        if (!readDateTime)
                        {
                            thisDate = logEntry.Substring(0, tab1); //Get date of this entry
                            thisTime = logEntry.Substring(tab1 + 1, tab2 - tab1 - 1); //get time of this entry
                            tab1 = logEntry.IndexOf("\t", tab2 + 1);
                            thisUser = logEntry.Substring(tab2 + 1, tab1 - tab2 - 1); //get user of this entry -- logEntry.IndexOf("\t", tab2 + 1)
                            tab2 = logEntry.IndexOf("\t", tab1 + 1);
                            thisSessionID = logEntry.Substring(tab1 + 1, tab2 - tab1 - 1);//Gets the session ID
                            readDateTime = true;
                        }
                    }
                    thisURI = logEntry.Substring(tab1 + 1, tab2 - tab1 - 1);
                    string thisExtension = "";

                    //Check for double http marker, skip those
                    int pos1 = thisURI.IndexOf("http"); //Find first http
                    if (thisURI.IndexOf("http", pos1 + 4) == -1) //Did NOT find a second http, so keep processing
                    {
                        for (int i = 0; i < numberAllowedURI; i++) //Run through all the allowed URIs
                        {
                            if (thisURI.IndexOf(allowedURI[i, 0]) != -1) //Current URI from allowed list is the current URI from the log? Then proceed, otherwise get the next from the list
                            {
                                int keepIndex = i;
                                i = numberAllowedURI; //make sure to step out of the for loop after processing
                                Console.WriteLine("Found: " + thisURI);
                                bool searchPoint = true;
                                bool keepThis = false;
                                int step = 1;
                                while (searchPoint) //Find either a "/" at the end (URI without file name) or find the "." to extract the extension
                                {
                                    int location = thisURI.Length - step; //Walk through characters from the end of the URI string
                                    if (thisURI.Substring(location, 1) == "/")
                                    {
                                        //No file name in the URI, we'll keep this one
                                        keepThis = true; //This makes sure the check against file name extensions is skipped
                                        searchPoint = false; //stop the loop
                                        Console.WriteLine("Found a / in the URI. Keeping URI");
                                    }
                                    if (thisURI.Substring(location, 1) == ".")
                                    {
                                        //have we found a point? Then extract the file name extension
                                        if (thisURI.Length - location - 1 >= 0)
                                        {
                                            thisExtension = thisURI.Substring(location + 1, thisURI.Length - location - 1);
                                            searchPoint = false;
                                            Console.WriteLine("Found a periode. Extracted extension: " + thisExtension);
                                        }
                                    }
                                    step++; //get the next character from the end of the URI
                                }

                                if (!keepThis) //Test against the file name extensions if this URI is allowed
                                {
                                    for (int j = 0; j < allowedExtensions.Count(); j++)
                                    {
                                        if (thisExtension == allowedExtensions[j])
                                        {
                                            keepThis = true;
                                            Console.WriteLine("This extensions is allowed: " + allowedExtensions[j]);
                                            j = allowedExtensions.Count();
                                        }
                                    }
                                    if (!keepThis) { blockIt = true; }
                                }
                                //Check if this URI is in the blocked list
                                if (keepThis)
                                {
                                    for (int j = 0; j < numberBlockedURI; j++) //Now run through the blocked URI list
                                    {
                                        if (thisURI.IndexOf(blockURI[j, 0]) != -1) //If it matched this URI was marked to NOT be included
                                        {
                                            Console.WriteLine("This URI should be blocked");
                                            blockIt = true;
                                            j = numberBlockedURI;
                                        }
                                    }
                                }
                                //Check for duplicate of last
                                //This only checks two consecutive log entries. So it is possible that a duplicate may slip through
                                //This is what the duplicate check should do:
                                //If it's the same sessionID then we just safe 1 URL, usually a web page redirects to another URL with the same content. In other words only 1 is NOT blocked
                                //If a user visits the same web site, but after more than 5 minutes, the session ID will NOT be the same, so it is accepted as a new entry
                                //If a user visits the same web site within 5 minutes, but has visited another web site between the recurring visits, then there'll be a new session ID, so it will be a new entry

                                //First duplicate check: if two consequtive entries have the same Session ID, it is the same web page even if the URI is different. Usually a redirect.
                                //This just does not work!!
                                /*
                                if (thisSessionID == prevSessionID) //check if the session ID is the same
                                {
                                    blockIt = true; //If so, this is a duplicate entry, ignore it!
                                }
                                */
                                if (!blockIt) //URI valid?
                                {
                                    //Clean the line to remove unwanted columns
                                    //data, time, username, time-taken, client ip address (c-ip), (agent), URI, sc-bytes (server side bytes)
                                    //and add the Category [1], Owner [2], Brand [3], Region [4], Subject [5], Template [6], Source [7]
                                    //logEntry = cleanLine(logEntry);
                                    logEntry = cleanLine(logEntry) + "," + allowedURI[keepIndex, 1] + "," + allowedURI[keepIndex, 2] + "," + allowedURI[keepIndex, 3]
                                         + "," + allowedURI[keepIndex, 4] + "," + allowedURI[keepIndex, 5] + "," + allowedURI[keepIndex, 6] + "," + allowedURI[keepIndex, 7];
                                    cleanedLogFile.WriteLine(logEntry); //Write it to the cleaned log file
                                }
                                blockIt = false; //reset
                            }
                        }
                    }
                    else
                    {
                        //skip it!
                        Console.WriteLine("Found double http");
                    }
                    //Save these values for the next run to check for duplicates
                    prevDate = thisDate;
                    prevTime = thisTime;
                    prevUser = thisUser;
                    prevSessionID = thisSessionID;
                    prevURI = thisURI;
                }
                rawLogFile.Close();
                cleanedLogFile.Close();

                //So now we've got a cleaned log file, but we still need to check for additional duplicate conditions.
                //If a user visits the same web site, but after more than 5 minutes, the session ID will NOT be the same, so it is accepted as a new entry
                //If a user visits the same web site within 5 minutes, but has visited another web site between the recurring visits, then there'll be a new session ID, so it will be a new entry
                //Call the final clean method:

                removeDuplicates();

                rawLogFile.Close();
                cleanedLogFile.Close();

                //Write to server share
                //string destination = @" 145.108.224.10\NewsTracker\" + fileName.Substring(0,8) + "_clean.txt";
                //File.Copy(path + fileName.Substring(0,8) + "_clean.txt", destination);
                //Copy the raw proxy log file to the News Tracker share on the NAS
                try
                {
                    File.Copy(pathProxy + fileName, @"\\145.108.224.10\NewsTracker\raw logs\" + fileName);
                }
                catch (IOException ex)
                {
                    Console.WriteLine(ex.Message);
                }

                Console.WriteLine("Done Cleaning");
                //Console.ReadKey();

                string[] weProjects = ContentExtractor.GetContent(pathRoot, pathProxy, pathLogsRaw, pathLogsClean, pathContent, pathConfig, pathTemplates, pathLogsFinal, fileName.Substring(0, 8), "_clean.txt");
                Console.WriteLine("Done with Content Extration");
                //Console.ReadKey();

                FileMerger.Merge(pathRoot, pathProxy, pathLogsRaw, pathLogsClean, pathContent, pathConfig, pathTemplates, pathLogsFinal, fileName.Substring(0, 8), "_clean.txt", weProjects);
                Console.WriteLine("Done with File Merging");
                //Console.ReadKey();
            //Now copy files to the server for access
            try
            {
                File.Copy(pathLogsFinal + fileName.Substring(0, 8) + "_finalLog.txt", @"\\145.108.224.10\NewsTracker\" + fileName.Substring(0, 8) + "_finalLog.txt");
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
            try
            {
                File.Copy(pathLogsFinal + fileName.Substring(0, 8) + "_fullLog.txt", @"\\145.108.224.10\NewsTracker\" + fileName.Substring(0, 8) + "_fullLog.txt");
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
            //Console.ReadKey();
        }

        //This extracts only the wanted fields from the log entry and makes it comma seperated
        string cleanLine(string line)
        {
            string cleanedLine = "";
            string delimiter = "\t"; //
            //TAB 1 = Date
            int tab1 = line.IndexOf(delimiter);
            cleanedLine += line.Substring(0, tab1) + ","; //add date to output line and add comma
            //TAB 2 = time
            int tab2 = line.IndexOf(delimiter, tab1 + 1);
            cleanedLine += line.Substring(tab1 + 1, tab2 - tab1 - 1) + ",";
            //TAB 3 = Username
            tab1 = line.IndexOf(delimiter, tab2 + 1);
            cleanedLine += line.Substring(tab2 + 1, tab1 - tab2 - 1) + ",";
            //TAB 4 = session id
            tab2 = line.IndexOf(delimiter, tab1 + 1);
            cleanedLine += line.Substring(tab1 + 1, tab2 - tab1 - 1) + ",";
            //TAB 5 = time taken
            tab1 = line.IndexOf(delimiter, tab2 + 1);
            cleanedLine += line.Substring(tab2 + 1, tab1 - tab2 - 1) + ",";
            //TAB 6 = client ip
            tab2 = line.IndexOf(delimiter, tab1 + 1);
            cleanedLine += line.Substring(tab1 + 1, tab2 - tab1 - 1) + ",";
            //TAB 7 = client agent - skipping
            tab1 = line.IndexOf(delimiter, tab2 + 1);
            //cleanedLine += line.Substring(tab2 + 1, tab1 - tab2 - 1) + ",";
            //TAB 8 = server ip - skipping
            tab2 = line.IndexOf(delimiter, tab1 + 1);
            //cleanedLine += line.Substring(tab1 + 1, tab2 - tab1 - 1) + ",";
            //TAB 9 = serer method - skipping
            tab1 = line.IndexOf(delimiter, tab2 + 1);
            //cleanedLine += line.Substring(tab2 + 1, tab1 - tab2 - 1) + ",";
            //TAB 10 = URI
            tab2 = line.IndexOf(delimiter, tab1 + 1);
            cleanedLine += line.Substring(tab1 + 1, tab2 - tab1 - 1) + ",";
            //TAB 11 = URI query - skipping
            tab1 = line.IndexOf(delimiter, tab2 + 1);
            //cleanedLine += line.Substring(tab2 + 1, tab1 - tab2 - 1) + ",";
            //TAB 12 = server status - skipping
            tab2 = line.IndexOf(delimiter, tab1 + 1);
            //cleanedLine += line.Substring(tab1 + 1, tab2 - tab1 - 1) + ",";
            //TAB 13 = client bytes - skipping
            tab1 = line.IndexOf(delimiter, tab2 + 1);
            //cleanedLine += line.Substring(tab2 + 1, tab1 - tab2 - 1) + ",";
            //TAB 14 = server bytes
            tab2 = line.IndexOf(delimiter, tab1 + 1);
            cleanedLine += line.Substring(tab1 + 1, tab2 - tab1 - 1);

            return (cleanedLine);
        }

        string getDate(int fileIndex)
        {
            string prefixString, month, day, index;
            DateTime currentDate = DateTime.Today;

            int currentYear = currentDate.Year;
            int currentMonth = currentDate.Month;
            int currentDay = currentDate.Day;
            string suffixName = "WWW Proxy Server.log";

            currentDay--; //Get yesterday
            if (currentDay < 1)
            {
                currentMonth--;
                if (currentMonth < 1)
                {
                    currentYear--;
                    currentMonth = 12;
                }
                switch (currentMonth)
                {
                    case 1:
                        currentDay = 31;
                        break;
                    case 2:
                        currentDay = 28;
                        break;
                    case 3:
                        currentDay = 31;
                        break;
                    case 4:
                        currentDay = 30;
                        break;
                    case 5:
                        currentDay = 31;
                        break;
                    case 6:
                        currentDay = 30;
                        break;
                    case 7:
                        currentDay = 31;
                        break;
                    case 8:
                        currentDay = 31;
                        break;
                    case 9:
                        currentDay = 30;
                        break;
                    case 10:
                        currentDay = 31;
                        break;
                    case 11:
                        currentDay = 30;
                        break;
                    case 12:
                        currentDay = 31;
                        break;
                }
            }

            if (currentDay < 10)
            {
                day = "0" + currentDay.ToString();
            }
            else
            {
                day = currentDay.ToString();
            }
            if (currentMonth < 10)
            {
                month = "0" + currentMonth.ToString();
            }
            else
            {
                month = currentMonth.ToString();
            }
            if (fileIndex < 10)
            {
                index = "00" + fileIndex.ToString();
            }
            else if (fileIndex < 100)
            {
                index = "0" + fileIndex.ToString();
            }
            else
            {
                index = fileIndex.ToString();
            }

            prefixString = currentYear.ToString() + month + day + "_" + index + "_" + suffixName;
            //prefixString = "20140421_000_" + suffixName; //debug only
            return prefixString;
        }

        string[,] getURIs(int readOrnot) //Reads a text file with 1 URI on each line - block = 0 / allow = 1
        {
            //Console.WriteLine("---");
            string[,] uri = new string[5000,8]; //default 500
            int index = 0;
            StreamReader myURIs = new StreamReader(pathConfig + "uris.txt"); //Local
            //StreamReader myURIs = new StreamReader("c:\\Program Files\\News Tracker\\uris.txt"); //remote
            while (true)
            {
                string line = myURIs.ReadLine();
                if (line == null) { break; }
                //Extact the fields: URI, Category, Owner, Brand, Region, Subject, Template, Source
                int comma1 = line.IndexOf(","); //Find the first comma after the URI
                int comma2 = line.IndexOf(",", comma1 + 1); //Find the second comma after the Category
                int comma3 = line.IndexOf(",", comma2 + 1); //Find the third comma after the Owner
                int comma4 = line.IndexOf(",", comma3 + 1); //Find the comma after the Brand
                //Added
                int comma5 = line.IndexOf(",", comma4 + 1); //Find the comma after the Region
                int comma6 = line.IndexOf(",", comma5 + 1); //Find the comma after the Subject
                int comma7 = line.IndexOf(",", comma6 + 1); //Find the comma after the Template

                string URI = line.Substring(0, comma1); //Get the URI
                string CAT = line.Substring(comma1 + 1, comma2 - comma1 - 1); //Get the Category
                string OWN = line.Substring(comma2 + 1, comma3 - comma2 - 1); //Get the Owner
                string BRD = line.Substring(comma3 + 1, comma4 - comma3 - 1); //Get the Brand
                //Added
                string RGN = line.Substring(comma4 + 1, comma5 - comma4 - 1); //Get the Region
                string SBJ = line.Substring(comma5 + 1, comma6 - comma5 - 1); //Get the Subject
                string TPL = line.Substring(comma6 + 1, comma7 - comma6 - 1); //Get the Template
                string SRC = line.Substring(comma7 + 1, line.Length - comma7 - 1); //Get the Source

                //if(line.Substring(0,1) == "X" && readOrnot == 0){ //Found initial X, so skipping this URI
                if(URI.Substring(0,1) == "X" && readOrnot == 0){ //Found initial X, so skipping this URI
                    //uri[index] = line.Substring(1); //Strip line of X
                    uri[index, 0] = URI.Substring(1); //Strip line of X
                    //Console.WriteLine(uri[index]);
                    index++;
                }
                //else if (line.Substring(0, 1) != "X" && readOrnot == 1)
                else if (URI.Substring(0, 1) != "X" && readOrnot == 1)
                { //No X found so keep this one
                    //uri[index] = line;
                    uri[index, 0] = URI;
                    uri[index, 1] = CAT; //Only need these if this is a valid URI
                    uri[index, 2] = OWN;
                    uri[index, 3] = BRD;

                    //Added
                    uri[index, 4] = RGN;
                    uri[index, 5] = SBJ;
                    uri[index, 6] = TPL;
                    uri[index, 7] = SRC;
                    //Console.WriteLine(uri[index]);
                    index++;
                }
            }
            myURIs.Close();
            if (readOrnot == 0)
            {
                numberBlockedURI = index;
            }
            else
            {
                numberAllowedURI = index;
            }
            return uri;
        }

        void fillExtensions()
        {
            allowedExtensions[0] = "html";
            allowedExtensions[1] = "htm";
            allowedExtensions[2] = "dhtml";
            allowedExtensions[3] = "shtml";
            allowedExtensions[4] = "php";
            allowedExtensions[5] = "asp";
            allowedExtensions[6] = "jsp";
        }

        int MinutesPassed( string pTime, string tTime)
        {
            //First extract the hours and minutes and convert them to INT
            //Of previous log entry
            int pos1 = pTime.IndexOf(":");
            int pHours = Convert.ToInt16(pTime.Substring(0, 2));
            int pMins = Convert.ToInt16(pTime.Substring(pos1 + 1, 2));
            //Of current log entry
            pos1 = tTime.IndexOf(":");
            int tHours = Convert.ToInt16(tTime.Substring(0, 2));
            int tMins = Convert.ToInt16(tTime.Substring(pos1 + 1, 2));
            //Get the difference in minutes
            int diffMins = ((tHours * 60) + tMins) - ((pHours * 60) + pMins);
            return diffMins;
        }

        int secondsPassed(string pTime, string tTime)
        {
            //First extract the hours, minutes and seconds and convert them to INT
            //Of previous log entry
            int pHours = Convert.ToInt16(pTime.Substring(0, 2));
            int pMins = Convert.ToInt16(pTime.Substring(3, 2));
            int pSecs = Convert.ToInt16(pTime.Substring(6, 2));
            //Of current log entry
            int tHours = Convert.ToInt16(tTime.Substring(0, 2));
            int tMins = Convert.ToInt16(tTime.Substring(3, 2));
            int tSecs = Convert.ToInt16(tTime.Substring(6, 2));
            //Get the difference in minutes
            int diffSecs = ((tHours * 60 * 60) + (tMins * 60) + tSecs) - ((pHours * 60 * 60) + (pMins * 60) + pSecs);
            return Math.Abs(diffSecs);
        }

        void removeDuplicates()
        {
            //This opens the first version of the cleaned logfile and checks for additional duplicates
            //If a user visits the same web site, but after more than 5 minutes, the session ID will NOT be the same, so it is accepted as a new entry
            //If a user visits the same web site within 5 minutes, but has visited another web site between the recurring visits, then there'll be a new session ID, so it will be a new entry

            string[] logLines = new string[10000]; //This will hold the phase 1 cleaned log entries
            int arrayIndex = 0; //Just an index of the logLines array
            int numberEntries = 0; //Holds the number of lines in the temporary log file and thus in the array
            prevUser = ""; //Clear these vars
            prevTime = "00:00:00";
            prevURI = "";
            bool skipIt = false;
            
            //fileName = getDate(index); //Get the dated file name of yesterday
            //Open the previously created cleaned file called ....._cleantemp
            rawLogFile = new StreamReader(pathLogsRaw + fileName.Substring(0, 8) + "_cleantemp.txt");
            //Now create the final cleaned log file
            cleanedLogFile = new StreamWriter(pathLogsClean + fileName.Substring(0, 8) + "_clean.txt");
            while (true) //loop
            {
                string readLine = rawLogFile.ReadLine(); //read a line from the temp cleaned file
                if (readLine == null) { break; } //EOF? then exit loop
                logLines[arrayIndex] = readLine; //transfer to the array
                arrayIndex++;
            }
            rawLogFile.Close(); //Don't need this any more
            numberEntries = arrayIndex - 1; //Store the number of entries

            //Now the phase 1 log file is read into the logLines array

            int currentLine = 0; //current record we're processing
            while (currentLine < numberEntries + 1) //loop through the entire set
            {
                //logLines[currentLine] is the current entry
                getValues(logLines[currentLine], "this"); //Get Time, User, URI and Session ID
                //loop through all the previous entries
                for (int i = 0; i < currentLine; i++)
                {
                    getValues(logLines[i], "prev"); //Get the user, time and URI of this previous log entry
                    //First check the Session ID
                    //This does not work as the first URI is not always the URI we need to keep, no way to determine that!
                    /*
                    if (thisSessionID == prevSessionID) //If the same then we only keep the first, if not keep checking
                    {
                        skipIt = true;
                        Console.WriteLine("Found duplicate on Session ID");
                        Console.WriteLine(logLines[currentLine]);
                        Console.WriteLine(logLines[i]);
                    }
                     * */
                    if (thisUser == prevUser && !skipIt) //First make sure it's the same user
                    {
                        if (thisURI == prevURI) //Then make sure it's the same URI
                        {
                            if (secondsPassed(thisTime, prevTime) < (5 * 60)) //If less than 5 minutes have passed, drop this entry
                            {
                                skipIt = true;
                                Console.WriteLine("Found duplicate within 5 minutes");
                                Console.WriteLine(logLines[currentLine]);
                                Console.WriteLine(logLines[i]);
                            }
                        }
                    }
                }
                if (!skipIt)
                {
                    cleanedLogFile.WriteLine(logLines[currentLine]); //Write out the entire log entry
                }
                skipIt = false;

                currentLine++; // Get the next entry
                //prevTime = thisTime;
                //prevUser = thisUser;
                //prevURI = thisURI;
            }
        }

        void getValues(string logEntry, string thisprev)
        {
            //Structure: date,time,user,session ID,request time,server IP,URI,bytes transfered from server

            //Just exstract the time, session ID, user and URI
            int comma1 = logEntry.IndexOf(","); //get first comma - between date and time
            int comma2 = logEntry.IndexOf(",", comma1 + 1);//get next comma - between time and user
            string theTime = logEntry.Substring(comma1 + 1, comma2 - comma1 - 1); //Get time
            comma1 = logEntry.IndexOf(",", comma2 + 1); //get comma between user and session ID
            string theUser = logEntry.Substring(comma2 + 1, comma1 - comma2 - 1); //Get user name
            comma2 = logEntry.IndexOf(",", comma1 + 1);//get next comma - between session ID and request time
            string theSessionID = logEntry.Substring(comma1 + 1, comma2 - comma1 - 1); //Get Session ID
            comma1 = logEntry.IndexOf(",", comma2 + 1); //get comma between request time and server ip
            comma2 = logEntry.IndexOf(",", comma1 + 1);//get next comma - between server ip and URI
            comma1 = logEntry.IndexOf(",", comma2 + 1); //get comma between URI and bytes transfered
            string theURI = logEntry.Substring(comma2 + 1, comma1 - comma2 - 1); //Get URI
            if (thisprev == "this")
            {
                thisTime = theTime;
                thisSessionID = theSessionID;
                thisUser = theUser;
                thisURI = theURI;
            }
            else
            {
                prevTime = theTime;
                prevSessionID = theSessionID;
                prevUser = theUser;
                prevURI = theURI;
            }
        }
    }
}
