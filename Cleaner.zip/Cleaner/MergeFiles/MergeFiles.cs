﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace MergeFiles
{
    public class MergeResultFiles
    {
        public void Merge(string pathRoot, string pathProxy, string pathLogsRaw, string pathLogsClean, string pathContent, string pathConfig, string pathTemplates, string pathLogsFinal, string fileName, string extension, string[] weProjects)
        {
            //path = .\Logs
            //fileName = yyyymmdd 
            //extension = _clean.txt
            //weProjects hold all the currently defined WE porject files in the .\Config\WEprojects folder

            int index = 0;
            string[,] mergedLines = new string[10000, 2]; //[x,0] = log entry, [x,1] = content entry if available

            //Open the cleaned log file of today
            StreamReader cleanedLogFile = new StreamReader(pathLogsClean + fileName + extension);
            string readLine = cleanedLogFile.ReadLine();
            while (readLine != null)
            {
                mergedLines[index, 0] = readLine;
                readLine = cleanedLogFile.ReadLine();
                index++;
            }
            cleanedLogFile.Close();

            index = 0;
            //Need to walk through all the WEprojects to merge each of the web site (WE project) files into the single cleaned log file of today
            while (weProjects[index] != null)
            {
                //Open the content file
                StreamReader contentOutFile = null;
                try
                {
                    contentOutFile = new StreamReader(pathContent + fileName + "_content_" + weProjects[index].Replace(".", "_") + ".txt");
                }
                catch (IOException ex)
                {
                    //Console.WriteLine(ex.Message);
                }
                //Read lines
                if (contentOutFile != null)
                {
                    string contentLine = contentOutFile.ReadLine();
                    while (contentLine != null)
                    {
                        //Extract the Session ID
                        int comma = contentLine.IndexOf(","); //get first comma
                        string sessionID = contentLine.Substring(0, comma); //get the session ID
                        //Scan through the cleaned log file for this session ID
                        int pos = 0;
                        while (mergedLines[pos, 0] != null)
                        {
                            //Find 3rd anbd 4th comma
                            int comma1 = mergedLines[pos, 0].IndexOf(","); //first
                            int comma2 = mergedLines[pos, 0].IndexOf(",", comma1 + 1); //second
                            comma1 = mergedLines[pos, 0].IndexOf(",", comma2 + 1); //third
                            comma2 = mergedLines[pos, 0].IndexOf(",", comma1 + 1); //fourth
                            string logSessionID = mergedLines[pos, 0].Substring(comma1 + 1, comma2 - comma1 - 1); //Get the ID from the log file entry
                            //If found append the content line, repeat until EOF cleaned log file (could be more that 1 URL!)
                            if (logSessionID == sessionID)
                            {
                                mergedLines[pos, 1] = contentLine;
                            }
                            pos++;
                        }
                        contentLine = contentOutFile.ReadLine();
                    }
                }

                //When no more lines in current content file, open the next one

                index++;
            }

            StreamWriter finalOutputFile = new StreamWriter(pathLogsFinal + fileName + "_finalLog.txt"); //only contains the entries with content
            StreamWriter fullOutputFile = new StreamWriter(pathLogsFinal + fileName + "_fullLog.txt"); //contains all cleaned log entries, including those with content and without content
            index = 0;
            while (mergedLines[index, 0] != null)
            {
                string content = "no content"; //use when including records without any content
                if (mergedLines[index, 1] != null)
                {
                    int comma = mergedLines[index, 1].IndexOf(","); //find the comma after the session id in the content part
                    content = mergedLines[index, 1].Substring(comma + 1, mergedLines[index, 1].Length - comma - 1); //remove the string
                    finalOutputFile.WriteLine(mergedLines[index, 0] + "," + content); //remark this if records without content should be logged too
                    fullOutputFile.WriteLine(mergedLines[index, 0] + "," + content); //remark this if records without content should be logged too
                }
                else
                {
                    fullOutputFile.WriteLine(mergedLines[index, 0] + "," + content); //use when including records without any content
                }
                index++;
            }
            finalOutputFile.Close();
            fullOutputFile.Close();
        }
    }
}
